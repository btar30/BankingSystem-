package com.example.demo.exception.ExcAccount;

// كلاس مخصص يرمى عندما يحاول أحد السحب أو الإيداع من حساب مجمد
public class AccountFrozenException extends RuntimeException {

    public AccountFrozenException(String message) {
        super(message);
    }
}
