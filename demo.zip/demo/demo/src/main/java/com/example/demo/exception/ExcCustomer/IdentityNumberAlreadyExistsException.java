package com.example.demo.exception.ExcCustomer;

public class IdentityNumberAlreadyExistsException extends RuntimeException {
    public IdentityNumberAlreadyExistsException(String message) {
        super(message);
    }
}
