package com.example.demo.service.impl;

import com.example.demo.dto.RequestDTO.EmployeeRequestDTO;
import com.example.demo.dto.RequestDTO.EmployeeUpdateRequestDTO;
import com.example.demo.dto.ResponseDTO.EmployeeResponseDTO;

import com.example.demo.exception.ExcEmployee.EmployeeNotFoundException;
import com.example.demo.exception.ExcEmployee.BadRequestException;
import com.example.demo.exception.ExcEmployee.UsernameAlreadyExistsException;
import com.example.demo.model.Employee;
import com.example.demo.model.enums.Role;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.service.EmployeeService;

import org.springframework.security.crypto.password.PasswordEncoder; // للأمن والتشفير

 org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final PasswordEncoder passwordEncoder; // تشفير الباسورد قبل الحفظ

    // Constructor Injection (أفضل من @Autowired لسهولة التيست ونظافة الكود)
    public EmployeeServiceImpl(EmployeeRepository employeeRepository, PasswordEncoder passwordEncoder) {
        this.employeeRepository = employeeRepository;
        this.passwordEncoder = passwordEncoder;
    }

    //===========================================================
    //  1.إنشاء موظف جديد
    //===========================================================
    @Override
    @Transactional
    public EmployeeResponseDTO createEmployee(EmployeeRequestDTO requestDTO) {
        if (employeeRepository.existsByUsername(requestDTO.getUsername())) {
            throw new UsernameAlreadyExistsException("عذراً، اسم المستخدم مسجل مسبقاً في النظام!");
        }
        if (employeeRepository.existsByEmail(requestDTO.getEmail())) {
            throw new UsernameAlreadyExistsException("عذراً، البريد الإلكتروني مستخدم لموظف آخر!");
        }
        Employee employee = new Employee();

        employee.setFirstName(requestDTO.getFirstName());
        employee.setLastName(requestDTO.getLastName());
        employee.setEmail(requestDTO.getEmail());
        employee.setPhoneNumber(requestDTO.getPhoneNumber());
        employee.setSalary(requestDTO.getSalary());
        employee.setRole(requestDTO.getRole());
        employee.setUsername(requestDTO.getUsername());

        employee.setActive(true);
        employee.setHireDate(LocalDate.now());

        String encryptedPassword = passwordEncoder.encode(requestDTO.getPassword());
        employee.setPassword(encryptedPassword);

        employee.setHireDate(java.time.LocalDate.now());       // تاريخ التعيين (اليوم)
        employee.setCreatedAt(java.time.LocalDateTime.now()); // تاريخ إنشاء السجل (الآن بالثانية)
        employee.setActive(true);                             // الحساب نشط تلقائياً عند الإنشاء

        Employee savedEmployee = employeeRepository.save(employee);
        //  إرجاع الـ DTO النظيف للواجهة
        return mapToResponseDTO(savedEmployee);
    }
    //===========================================================
    //2.البحث عن موظف بالـ id
    //===========================================================
    @Override
    public EmployeeResponseDTO getEmployeeById(Long id) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new EmployeeNotFoundException("لم يتم العثور على الموظف برقم الـ ID: " + id));
        return mapToResponseDTO(employee);
    }
    //===========================================================
    // 3.جلب كل الموظفين في البنك
    //===========================================================
    @Override
    public List<EmployeeResponseDTO> getAllEmployees() {
        return employeeRepository.findAll()
                .stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
    }
    //===========================================================
    //4.جلب الموظفين بحسب دورهم (مثلاً لرؤية كل الـ Tellers)
    //===========================================================
    @Override
    public List<EmployeeResponseDTO> getEmployeesByRole(Role role) {
        return employeeRepository.findByRole(role)
                .stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
    }
    //===========================================================
    //5.تعطيل حساب موظف (إيقافه عن العمل دون حذفه)
    //===========================================================
    @Override
    @Transactional
    public void deactivateEmployee(Long id) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new UsernameAlreadyExistsException("الموظف غير موجود لتعديل حالته"));

        employee.setActive(false);
        employeeRepository.save(employee);
    }
    //===========================================================
    // 6.تفعيل حساب موظف مجدداً
    //===========================================================
    @Override
    @Transactional
    public void activateEmployee(Long id) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new UsernameAlreadyExistsException("الموظف غير موجود لتعديل حالته"));
        employee.setActive(true);
        employeeRepository.save(employee);
    }
    //===========================================================
    //7. تعديل دور موظف معين في النظام البنكي عن طريق id
    //===========================================================
    @Transactional
    public EmployeeResponseDTO updateEmployeeRole(Long id, String newRole) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new UsernameAlreadyExistsException("الموظف المطلوب غير موجود في النظام."));
        try {
            employee.setRole(Role.valueOf(newRole.toUpperCase()));
        } catch (IllegalArgumentException e) {
            throw new BadRequestException("الصلاحية المدخلة غير مدعومة في النظام البنكي.");
        }
        Employee updatedEmployee = employeeRepository.save(employee);
        return mapToResponseDTO(updatedEmployee);
    }
    //=======================================================
    //8.حذف بيانات موظف
    //======================================================
    @Transactional
    public void deleteEmployee(Long id) {
        if (!employeeRepository.existsById(id)) {
            throw new UsernameAlreadyExistsException("الموظف المراد حذفه غير موجود في النظام.");
        }
        employeeRepository.deleteById(id);
    }
    // ==========================================
    //9.تعديل كامل لبيانات احد الموظفين
    // ==========================================
    @Transactional
    public EmployeeResponseDTO updateEmployeeFully(Long id, EmployeeUpdateRequestDTO updateRequest) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new UsernameAlreadyExistsException("الموظف المطلوب التعديل عليه غير موجود في النظام."));

        employee.setFirstName(updateRequest.getFirstName());
        employee.setLastName(updateRequest.getLastName());
        employee.setEmail(updateRequest.getEmail());
        employee.setPhoneNumber(updateRequest.getPhoneNumber());
        employee.setSalary(updateRequest.getSalary());
        employee.setRole(updateRequest.getRole());

        Employee updatedEmployee = employeeRepository.save(employee);

        return mapToResponseDTO(updatedEmployee);
    }
    //======================================================================
    // دالة مساعدة (Private Helper Method) لتحويل الـ Entity إلى Response DTO لتجنب تكرار الكود
    //======================================================================
    private EmployeeResponseDTO mapToResponseDTO(Employee employee) {
        return new EmployeeResponseDTO(
                employee.getId(),
                employee.getFirstName(), // سيتولى المشيد الجديد دمج الاسم الأول والأخير تلقائياً
                employee.getLastName(),
                employee.getEmail(),
                employee.getPhoneNumber(),
                employee.getSalary(),
                employee.getHireDate(),
                employee.getUsername(),
                employee.getRole(),
                employee.isActive(),
                employee.getCreatedAt(),
                employee.getUpdatedAt()
        );
    }
}