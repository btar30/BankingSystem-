package com.example.demo.service;

import com.example.demo.dto.RequestDTO.AccountRequestDTO;
import com.example.demo.dto.ResponseDTO.AccountResponseDTO;
import java.math.BigDecimal;
import java.util.List;

public interface AccountService {

    // 1. مهمة فتح حساب جديد وربطه بالعميل
    AccountResponseDTO createAccount(AccountRequestDTO requestDTO);

    // 2. مهمة جلب بيانات حساب معين بواسطة رقم الحساب
    AccountResponseDTO getAccountByNumber(String accountNumber);

    // 3. جلب كافة الحسابات التابعة لعميل معين بواسطة رقم الـ CIF (مهمة جداً لتطبيق الجوال)
    List<AccountResponseDTO> getAccountsByCustomerCif(String customerCif);

    // 4. عملية الإيداع المالي في حساب محدد
    AccountResponseDTO deposit(String accountNumber, BigDecimal amount);

    // 5. عملية السحب المالي من حساب محدد
    AccountResponseDTO withdraw(String accountNumber, BigDecimal amount);

    // 6. عملية التحويل المالي بين حسابين (من حساب المصدر إلى حساب الوجهة)
    void transfer(String sourceAccountNumber, String destinationAccountNumber, BigDecimal amount);

    // 7. تجميد الحساب البنكي (تغيير الحالة إلى FROZEN)
    void freezeAccount(String accountNumber);

    // 8. إعادة تنشيط الحساب البنكي المجمد (إعادته إلى ACTIVE)
    void activateAccount(String accountNumber);

    // 9. جلب قائمة كافة الحسابات في البنك (لأغراض الإدارة والتقارير)
    List<AccountResponseDTO> getAllAccounts();
}
