package com.example.demo.repository;

import com.example.demo.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

    // ==========================================
    // 1. استعلامات التحقق والأمن (Validation & Security)
    // ==========================================

    // جلب ملف العميل كاملاً بواسطة رقم العميل الموحد (CIF)
    Optional<Customer> findByCustomerNumber(String customerNumber);

    // جلب العميل بواسطة البريد الإلكتروني أو الهاتف (تستخدم لعمليات تسجيل الدخول)
    Optional<Customer> findByEmail(String email);
    Optional<Customer> findByPhoneNumber(String phoneNumber);

    // التأكد من عدم تكرار الهوية، الهاتف، أو الإيميل قبل الحفظ (ترجع true أو false)
    boolean existsByIdentityNumber(String identityNumber);
    boolean existsByPhoneNumber(String phoneNumber);
    boolean existsByEmail(String email);


    // ==========================================
    // 2. استعلامات البحث المتقدم والفلترة (Advanced Search)
    // ==========================================

    // جلب العميل بواسطة رقم هويته أو جواز سفره
    Optional<Customer> findByIdentityNumber(String identityNumber);

    // البحث الجزئي بالاسم الأول أو اسم العائلة (تلقائياً تحول إلى LIKE %name% في الـ SQL)
    List<Customer> findByFirstNameContainingIgnoreCaseOrLastNameContainingIgnoreCase(String firstName, String lastName);


    // ==========================================
    // 3. استعلامات الحالات والتقارير (Status & Analytics)
    // ==========================================

    // جلب العملاء حسب الحالة (نشطين أو موقوفين مؤقتاً)
    List<Customer> findByIsActive(boolean isActive);

    // جلب العملاء الذين سجلوا خلال فترة زمنية معينة (بالساعة والدقيقة) للتقارير
    List<Customer> findByCreatedAtBetween(LocalDateTime start, LocalDateTime end);


    // ==========================================
    // 4. استعلامات الربط المتقدمة والأداء (JPA Optimization)
    // ==========================================

    // حسم مشكلة الـ N+1: جلب بيانات العميل الموحد مع كافة حساباته البنكية بضربة واحدة في قاعدة البيانات
    @Query("SELECT c FROM Customer c LEFT JOIN FETCH c.accounts WHERE c.customerNumber = :customerNumber")
    Optional<Customer> findCustomerWithAccounts(@Param("customerNumber") String customerNumber);
}
