package com.example.demo.dto.ResponseDTO;

import com.example.demo.model.enums.Role;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class EmployeeResponseDTO {//خاص بارسال البيانات الامن
    private Long id;
    private String fullName;
    private String email;
    private String phoneNumber;
    private BigDecimal salary;
    private LocalDate hireDate; // تاريخ التعيين في البنك
    private String username;
    private Role role;
    private boolean isActive;
    private LocalDateTime createdAt;//تسجيل تاريخ الاضافه
    private LocalDateTime updatedAt; // تاريخ اخر عمليه التعديل

    // ==========================================
    // Constructors, Getters, and Setters
    // ==========================================

    public EmployeeResponseDTO() {}

    // المشيد الخاص
    public EmployeeResponseDTO(Long id, String fullName, String email, String phoneNumber,
                               BigDecimal salary, LocalDate hireDate, String username,
                               Role role, boolean isActive, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.salary = salary;
        this.hireDate = hireDate;
        this.username = username;
        this.role = role;
        this.isActive = isActive;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }


    // إضافة: مشيد ذكي يسهل عليك تحويل البيانات في طبقة الـ Service بدون تعقيد
    public EmployeeResponseDTO(Long id, String firstName, String lastName, String email, String phoneNumber,
                               BigDecimal salary, LocalDate hireDate, String username,
                               Role role, boolean isActive, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.id = id;
        this.fullName = firstName + " " + lastName; // الدمج التلقائي هنا داخل الـ DTO
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.salary = salary;
        this.hireDate = hireDate;
        this.username = username;
        this.role = role;
        this.isActive = isActive;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public BigDecimal getSalary() { return salary; }
    public void setSalary(BigDecimal salary) { this.salary = salary; }

    public LocalDate getHireDate() { return hireDate; }
    public void setHireDate(LocalDate hireDate) { this.hireDate = hireDate; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}