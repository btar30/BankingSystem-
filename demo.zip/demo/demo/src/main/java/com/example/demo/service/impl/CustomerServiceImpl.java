package com.example.demo.service.impl;

import com.example.demo.dto.ResponseDTO.CustomerResponseDTO;
import com.example.demo.dto.RequestDTO.CustomerRequestDTO;
import com.example.demo.exception.ExcCustomer.CustomerNotFoundException;
import com.example.demo.exception.ExcCustomer.EmailAlreadyExistsException;
import com.example.demo.exception.ExcCustomer.IdentityNumberAlreadyExistsException;
import com.example.demo.exception.ExcCustomer.PhoneNumberAlreadyExistsException;
import com.example.demo.model.Customer;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.service.CustomerService;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Year;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;

    // حقن الـ Repository عبر الـ Constructor (أفضل ممارسة في الـ Dependency Injection)
    public CustomerServiceImpl(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    // ==========================================
    // 1. تسجيل عميل جديد (Create Customer)
    // ==========================================
    @Override
    @Transactional
    public CustomerResponseDTO createCustomer(CustomerRequestDTO requestDTO) {

        if (customerRepository.existsByIdentityNumber(requestDTO.identityNumber())) {
            throw new IdentityNumberAlreadyExistsException("عذراً، رقم الهوية المدخل مسجل مسبقاً في النظام البنكي!");
        }
        if (customerRepository.existsByPhoneNumber(requestDTO.phoneNumber())) {
            throw new PhoneNumberAlreadyExistsException("عذراً، رقم الهاتف المدخل مستخدم بالفعل لعميل آخر!");
        }
        if (customerRepository.existsByEmail(requestDTO.email())) {
            throw new EmailAlreadyExistsException("عذراً، البريد الإلكتروني المدخل مستخدم بالفعل!");
        }

        // تحويل الـ Request DTO إلى Entity
        Customer customer = new Customer();
        customer.setFirstName(requestDTO.firstName());
        customer.setLastName(requestDTO.lastName());
        customer.setDateOfBirth(requestDTO.dateOfBirth());
        customer.setIdentityNumber(requestDTO.identityNumber());
        customer.setPhoneNumber(requestDTO.phoneNumber());
        customer.setEmail(requestDTO.email());
        customer.setPassword(requestDTO.password()); // ملاحظة: سيتم تشفيره لاحقاً عند ربط السيكيوريتي
        customer.setAddress(requestDTO.address());
        customer.setActive(true);

        // توليد رقم العميل الموحد (CIF) بشكل تلقائي وذكي (مثال: CIF202612345)
        String generatedCif = generateUniqueCifNumber();
        customer.setCustomerNumber(generatedCif);

        // الحفظ في قاعدة البيانات
        Customer savedCustomer = customerRepository.save(customer);

        // تحويل الـ Entity المحفوظ إلى Response DTO وإرجاعه للفرونت إند
        return mapToResponseDTO(savedCustomer);
    }

    // ==========================================
    // 2. جلب بيانات عميل محدد (Get Customer By CIF)
    // ==========================================
    @Override
    @Transactional(readOnly = true)
    public CustomerResponseDTO getCustomerByNumber(String customerNumber) {
        Customer customer = customerRepository.findByCustomerNumber(customerNumber)
                .orElseThrow(() -> new CustomerNotFoundException("عذراً، لم يتم العثور على أي عميل مسجل برقم الـ CIF: " + customerNumber));
        return mapToResponseDTO(customer);
    }

    // ==========================================
    // 3. جلب قائمة بكافة العملاء (Get All Customers)
    // ==========================================
    @Override
    @Transactional(readOnly = true)
    public List<CustomerResponseDTO> getAllCustomers() {
        return customerRepository.findAll().stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
    }

    // ==========================================
    // 4. تعديل بيانات العميل (Update Customer)
    // ==========================================
    @Override
    @Transactional
    public CustomerResponseDTO updateCustomer(String customerNumber, CustomerRequestDTO requestDTO) {
        // جلب العميل أو رمي استثناء إذا كان غير موجود
        Customer customer = customerRepository.findByCustomerNumber(customerNumber)
                .orElseThrow(() -> new CustomerNotFoundException("عذراً، العميل المراد تعديل بياناته غير موجود!"));

        // التحقق من تكرار الهاتف أو الإيميل إذا تم تغييرهما لعميل آخر
        if (!customer.getPhoneNumber().equals(requestDTO.phoneNumber()) && customerRepository.existsByPhoneNumber(requestDTO.phoneNumber())) {
            throw new PhoneNumberAlreadyExistsException("عذراً، رقم الهاتف الجديد مستخدم بالفعل لعميل آخر!");
        }
        if (!customer.getEmail().equals(requestDTO.email()) && customerRepository.existsByEmail(requestDTO.email())) {
            throw new EmailAlreadyExistsException("عذراً، البريد الإلكتروني الجديد مستخدم بالفعل لعميل آخر!");
        }

        // تحديث الحقول المسموح بتعديلها فقط (بيانات التواصل والعنوان)
        customer.setFirstName(requestDTO.firstName());
        customer.setLastName(requestDTO.lastName());
        customer.setPhoneNumber(requestDTO.phoneNumber());
        customer.setEmail(requestDTO.email());
        customer.setAddress(requestDTO.address());

        // حفظ التغييرات وتحويلها إلى Response DTO
        Customer updatedCustomer = customerRepository.save(customer);
        return mapToResponseDTO(updatedCustomer);
    }

    // ==========================================
    // 5. تعطيل حساب العميل (Soft Delete)
    // ==========================================
    @Override
    @Transactional
    public void deactivateCustomer(String customerNumber) {
        Customer customer = customerRepository.findByCustomerNumber(customerNumber)
                .orElseThrow(() -> new CustomerNotFoundException("عذراً، العميل المراد تجميد حسابه غير موجود!"));
        customer.setActive(false);
        customerRepository.save(customer);
    }

    // ==========================================
    // 6. إعادة تفعيل حساب العميل (Activate Customer)
    // ==========================================
    @Override
    @Transactional
    public void activateCustomer(String customerNumber) {
        Customer customer = customerRepository.findByCustomerNumber(customerNumber)
                .orElseThrow(() -> new CustomerNotFoundException("عذراً، العميل المراد إعادة تفعيل حسابه غير موجود!"));
        customer.setActive(true);
        customerRepository.save(customer);
    }

    // ==========================================
    // ميثودز مساعدة (Helper Methods) لرفع جودة الكود
    // ==========================================

    // دالة لتوليد رقم CIF فريد ومكون من 12 خانة (تجمع بين السنة الحالية وأرقام عشوائية ثابتة الطول)
//    private String generateUniqueCifNumber() {
//        int currentYear = Year.now().getValue(); // سيأخذ السنة الحالية تلقائياً (مثل 2026)
//        // توليد رقم تسلسلي عشوائي نظيف مكون من 8 أرقام
//        long randomNumber = (long) (Math.random() * 90000000L) + 10000000L;
//        return "CIF" + currentYear + randomNumber;
//    }

    private String generateUniqueCifNumber() {
        int currentYear = Year.now().getValue(); // 4 خانات (2026)
        // توليد رقم عشوائي مكون من 5 خانات فقط (بين 10000 و 99999)
        int randomNumber = (int) (Math.random() * 90000) + 10000;

        return "CIF" + currentYear + randomNumber; // المجموع الكلي = 12 خانة بالضبط
    }

    //====================================================================
    // دالة تحويل الـ Entity الملوكي إلى Response DTO
    private CustomerResponseDTO mapToResponseDTO(Customer customer) {
        return new CustomerResponseDTO(
                customer.getId(),
                customer.getCustomerNumber(),
                customer.getFirstName(),
                customer.getLastName(),
                customer.getIdentityNumber(),
                customer.getPhoneNumber(),
                customer.getEmail(),
                customer.getAddress(),
                customer.isActive(),
                customer.getCreatedAt()
        );
    }
}
