package com.example.demo.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResponse { //كلاس خاص بعرض رساله الخطاء يستخدمه كل النظام

    private LocalDateTime timestamp; // وقت حدوث الخطأ
    private int status;              // رقم الحالة مثل 400 أو 404
    private String error;            // نوع الخطأ
    private String message;          // الرسالة المفهومة للمستخدم
}
