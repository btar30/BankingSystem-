package com.example.demo.service.impl;

import com.example.demo.dto.RequestDTO.AccountRequestDTO;
import com.example.demo.dto.ResponseDTO.AccountResponseDTO;
import com.example.demo.exception.ExcAccount.AccountNotFoundException;
import com.example.demo.exception.ExcAccount.InsufficientBalanceException;
import com.example.demo.model.enums.AccountStatus;
import com.example.demo.service.AccountService;
import com.example.demo.model.Account;
import com.example.demo.model.Customer;
import com.example.demo.repository.AccountRepository;
import com.example.demo.repository.CustomerRepository;
//import com.example.demo.exception.CustomerNotFoundException;
import com.example.demo.exception.ExcCustomer.CustomerNotFoundException; // الحارس المخصص للعميل
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.Year;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final CustomerRepository customerRepository;

    // ==========================================
    //1. فتح حساب جديد وربطه بالعميل
    // ==========================================
    @Override
    @Transactional
    public AccountResponseDTO createAccount(AccountRequestDTO requestDTO) {

        // الخطوة 1: البحث عن العميل في مستودعه الخاص، وإذا لم يوجد يتدخل الحارس فوراً
        Customer customer = customerRepository.findByCustomerNumber(requestDTO.customerCif())
                .orElseThrow(() -> new CustomerNotFoundException("عذراً، لا يوجد عميل مسجل في النظام برقم الـ CIF المرفق"));

        // الخطوة 2: توليد رقم الحساب والـ IBAN الفريد تلقائياً عبر السيرفر
        String generatedAccountNumber = generateUniqueAccountNumber();
        String generatedIban = generateUniqueIban(generatedAccountNumber);

        // الخطوة 3: بناء وتعبئة كائن الحساب البنكي (Account Entity) باستخدام الـ Builder
        Account account = Account.builder()
                .accountNumber(generatedAccountNumber)
                .iban(generatedIban)
                .accountType(requestDTO.accountType())
                .currency(requestDTO.currency())
                .balance(requestDTO.initialBalance() != null ? requestDTO.initialBalance() : BigDecimal.ZERO)
                .status(AccountStatus.ACTIVE) // الحساب يفتح نشطاً تلقائياً
                .customer(customer) // هنا تم الربط الملوكي بين الحساب والعميل
                .build();

        // الخطوة 4: حفظ الحساب في قاعدة البيانات
        Account savedAccount = accountRepository.save(account);

        // الخطوة 5: تحويل الحساب المحفوظ إلى الـ ResponseDTO المنسق لشهاب
        return mapToResponseDTO(savedAccount);
    }

    // ==========================================
    // الدوال المساعدة (Helper Methods) لتوليد الأرقام البنكية
    // ==========================================

    // توليد رقم حساب فريد مكون من 20 خانة
    private String generateUniqueAccountNumber() {
        int currentYear = Year.now().getValue(); // 2026
        // توليد رقم عشوائي طويل لضمان عدم التكرار
        long randomNumber = (long) (Math.random() * 900000000000L) + 100000000000L;
        return "ACC" + currentYear + randomNumber;
    }

    // توليد رقم IBAN يمني فريد مطابق للمعايير الدولية (مثلاً 30 خانة)
    private String generateUniqueIban(String accountNumber) {
        // رمز اليمن YE + رقم فحص عشوائي (مثلاً 44) + رمز البنك الموحد (009) + رقم الحساب
        return "YE44009" + accountNumber.replace("ACC", "");
    }

    // دالة التحويل والخرائط (Mapping) من Entity إلى ResponseDTO
    private AccountResponseDTO mapToResponseDTO(Account account) {
        return new AccountResponseDTO(
                account.getId(),
                account.getAccountNumber(),
                account.getIban(),
                account.getAccountType(),
                account.getCurrency(),
                account.getBalance(),
                account.getStatus(),
                account.getCustomer().getFirstName() + " " + account.getCustomer().getLastName(), // دمج الاسم كامل
                account.getCustomer().getCustomerNumber(), // الـ CIF للعميل
                account.getCreatedAt(),
                account.getUpdatedAt()
        );
    }

    // ==========================================
    // 2. دالة جلب بيانات حساب عن طريق رقم الحساب
    // ==========================================
    @Override
    @Transactional(readOnly = true) // لمسة احترافية لتسريع عمليات القراءة وال
    public AccountResponseDTO getAccountByNumber(String accountNumber) {

        Account account = accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new CustomerNotFoundException("عذراً، لم يتم العثور على هذا الحساب في النظام البنكي"));

        return mapToResponseDTO(account);
    }

    // ==========================================
    // 3. داله جلب جميع الحسابات التابعه لعميل بوااسطه رقم العميل الخاص CIF
    // ==========================================
    @Override
    public List<AccountResponseDTO> getAccountsByCustomerCif(String customerCif) {
        return accountRepository.findByCustomerNumber(customerCif)
                .stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
    }

    // ==========================================
    // 4. عملية الإيداع المالي في حساب محدد
    // ==========================================
    @Override
    @Transactional // حماية ملوكية تضمن إتمام العملية بالكامل أو التراجع عنها في حال حدوث أي خطأ 🛡️
    public AccountResponseDTO deposit(String accountNumber, BigDecimal amount) {
        // الخطوة 1: الحراسة والجلب - البحث عن الحساب برقم الحساب
        Account account = accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(()-> new AccountNotFoundException("عذراً، لم يتم العثور على الحساب المحدد لإتمام عملية السحب"));
        // الخطوة 2: فحص الأمان - التأكد أن الحساب نشط وليس مجمداً أو مغلقاً 🛑
        if (account.getStatus() != AccountStatus.ACTIVE){
            throw new InsufficientBalanceException("عذرا لا يمكن الايداع الي حساب " + account.getStatus());
        }
        // الخطوة 3: زيادة الرصيد - استخدام دالة .add() الخاصة بـ BigDecimal لضمان دقة الكسور الماليّة ➕
        BigDecimal newBigDecimal = account.getBalance().add(amount);
        account.setBalance(newBigDecimal);

        // الخطوة 4: الحفظ المتين - حفظ الحساب بالرصيد الجديد في قاعدة البيانات 💾
        Account savedAccount = accountRepository.save(account);

        // الخطوة 5: التغليف والإرجاع - تحويل الحساب المحدث إلى DTO 🎁
        return mapToResponseDTO(savedAccount);

    }

    // ==========================================
    // 5. عملية السحب المالي من حساب محدد
    // ==========================================
    @Override
    @Transactional // حماية ملوكية تضمن سلامة الحركة الماليّة 🛡️
    public AccountResponseDTO withdraw(String accountNumber, BigDecimal amount) {

        // الخطوة 1: الحراسة والجلب - البحث عن الحساب
        Account account = accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new AccountNotFoundException("عذراً، لم يتم العثور على الحساب المحدد لإتمام عملية السحب"));

        // الخطوة 2: فحص الأمان - التأكد أن الحساب نشط وليس مجمداً 🛑
        if (account.getStatus() != AccountStatus.ACTIVE) {
            throw new IllegalStateException("عذراً، لا يمكن السحب من هذا الحساب لأن حالته حالياً: " + account.getStatus());
        }

        // الخطوة 3: الفحص الحرج - التأكد من كفاية الرصيد باستخدام .compareTo() ⚖️
        // compareTo ترجع -1 إذا كان الرصيد الحالي أقل من المبلغ المراد سحبه
        if (account.getBalance().compareTo(amount) < 0) {
            throw new InsufficientBalanceException("عذراً، لا يمكن إتمام العملية. الرصيد الحالي غير كافٍ!");
        }

        // الخطوة 4: خصم المبلغ - استخدام دالة .subtract() الخاصة بـ BigDecimal ➖
        BigDecimal newBalance = account.getBalance().subtract(amount);
        account.setBalance(newBalance);

        // الخطوة 5: الحفظ والإرجاع في قاعدة البيانات 💾🎁
        Account savedAccount = accountRepository.save(account);
        return mapToResponseDTO(savedAccount);
    }


    // ==========================================
    // 6. عملية التحويل المالي بين حسابين
    // ==========================================
    @Override
    @Transactional // حرييييييجة جداً هنا! تضمن تراجع السيرفر لو سحب من الأول وفشل في الإيداع للثاني 🛡️🚨
    public void transfer(String sourceAccountNumber, String destinationAccountNumber, BigDecimal amount) {

        // فحص أمني مبدئي: منع العميل من التحويل لنفس حسابه 🛑
        if (sourceAccountNumber.equals(destinationAccountNumber)) {
            throw new IllegalArgumentException("عذراً، لا يمكن تحويل مبلغ مالي إلى نفس الحساب!");
        }

        // فحص قيمة المبلغ: التأكد أن المبلغ المراد تحويله أكبر من صفر 💸
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("عذراً، يجب أن يكون مبلغ التحويل أكبر من الصفر!");
        }

        // الخطوة 1: تنفيذ عملية السحب من حساب المصدر (المرسل)
        // أعدنا استخدام دالة withdraw الذكية، وهي تتكفل بالبحث، وفحص الحالة النشطة، وفحص كفاية الرصيد تلقائياً! 🛒
        this.withdraw(sourceAccountNumber, amount);

        // الخطوة 2: تنفيذ عملية الإيداع في حساب الوجهة (المستقبل)
        // أعدنا استخدام دالة deposit الذكية، وهي تتكفل بالبحث وفحص حالة الحساب المستقبل تلقائياً! 📥
        this.deposit(destinationAccountNumber, amount);

        // العملية لا ترجع DTO لأن نوعها void في الـ Interface، وهي تتم خلف الكواليس بأمان تام
    }


    // ==========================================
    // 7. دالة تجميد حساب بنكي (لأسباب أمنية أو قانونية) ❄️
    // ==========================================
    @Override
    @Transactional // تحتاج ट्रांसएक्शन لأننا نقوم بتعديل الحالة في قاعدة البيانات 🛡️
    public void freezeAccount(String accountNumber) {

        // الخطوة 1: جلب الحساب والتأكد من وجوده
        Account account = accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new AccountNotFoundException("عذراً، لم يتم العثور على الحساب المراد تجميده"));

        // الخطوة 2: تغيير الحالة إلى مجمّد
        account.setStatus(AccountStatus.FROZEN);

        // الخطوة 3: الحفظ المتين في قاعدة البيانات
        accountRepository.save(account);
    }

    // ==========================================
    // 8. دالة تنشيط حساب بنكي (إعادة الحساب للخدمة) 🔥
    // ==========================================
    @Override
    @Transactional // تعديل وحفظ 🛡️
    public void activateAccount(String accountNumber) {

        // الخطوة 1: جلب الحساب والتأكد من وجوده
        Account account = accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new AccountNotFoundException("عذراً، لم يتم العثور على الحساب المراد تنشيطه"));

        // الخطوة 2: تغيير الحالة إلى نشط ومفتوح للعمليات الماليّة
        account.setStatus(AccountStatus.ACTIVE);

        // الخطوة 3: الحفظ المتين في قاعدة البيانات
        accountRepository.save(account);
    }

    // ==========================================
    // 9. دالة جلب جميع حسابات العملاء في البنك (للتقارير والإدارة) 📊
    // ==========================================
    @Override
    @Transactional(readOnly = true) // تسريع خارق للقراءة فقط لأنها تقارير ضخمة ⚡
    public List<AccountResponseDTO> getAllAccounts() {

        // الخطوة 1: جلب كل الحسابات بلا استثناء من قاعدة البيانات
        List<Account> allAccounts = accountRepository.findAll();

        // الخطوة 2: تحويل القائمة كاملة إلى قائمة DTOs فخمة لشهاب باستخدام الـ Stream
        return allAccounts.stream()
                .map(this::mapToResponseDTO)
                .toList();
    }



}
