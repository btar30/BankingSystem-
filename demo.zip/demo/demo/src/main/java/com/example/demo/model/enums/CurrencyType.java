package com.example.demo.model.enums;

public enum CurrencyType {
    YER, // الريال اليمني
    USD, // الدولار الأمريكي
    SAR, // الريال السعودي
    AED  // الدرهم الإماراتي
}
