package com.example.demo.model.enums;

public enum AccountType {
    CURRENT,   // حساب جاري
    SAVINGS,   // حساب توفير
    INVESTMENT // حساب استثماري
}
