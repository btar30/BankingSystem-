package com.example.demo.controller;

import com.example.demo.dto.RequestDTO.EmployeeRequestDTO;
import com.example.demo.dto.RequestDTO.EmployeeUpdateRequestDTO;
import com.example.demo.dto.ResponseDTO.EmployeeResponseDTO;
import com.example.demo.model.enums.Role;
import com.example.demo.service.EmployeeService;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/employees") // الرابط الرئيسي لعمليات الموظفين
public class EmployeeController {

    private final EmployeeService employeeService;

    // Constructor Injection لربط الـ Controller بالـ Service
    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }
    //=============================================================================
    // 1. رابط إنشاء موظف جديد (POST)
    //=============================================================================
    @PostMapping("/register")
    public ResponseEntity<EmployeeResponseDTO> registerEmployee(@Valid @RequestBody EmployeeRequestDTO requestDTO) {
        EmployeeResponseDTO response = employeeService.createEmployee(requestDTO); // يستقبل الـ RequestDTO الممتلئ بالبيانات، ويعيد الـ ResponseDTO الصافي
        return new ResponseEntity<>(response, HttpStatus.CREATED);
        //ASEEL_aman
        //Password123
    }
    //=============================================================================
    // 2. رابط البحث عن موظف بالـ ID (GET)
    //=============================================================================
    @GetMapping("/{id}")
    public ResponseEntity<EmployeeResponseDTO> getEmployeeById(@PathVariable Long id) {
        EmployeeResponseDTO response = employeeService.getEmployeeById(id);
        return ResponseEntity.ok(response); // إرجاع كود 200 نجاح
    }
    //=============================================================================
    // 3. رابط جلب كل موظفي البنك (GET)
    //=============================================================================
    @GetMapping
    public ResponseEntity<List<EmployeeResponseDTO>> getAllEmployees() {
        List<EmployeeResponseDTO> response = employeeService.getAllEmployees();
        return ResponseEntity.ok(response);
    }
    //=============================================================================
    // 4. رابط جلب الموظفين بحسب صلاحيتهم الإدارية (GET)
    //=============================================================================
    @GetMapping("/role/{role}")
    public ResponseEntity<List<EmployeeResponseDTO>> getEmployeesByRole(@PathVariable Role role) {
        List<EmployeeResponseDTO> response = employeeService.getEmployeesByRole(role);
        return ResponseEntity.ok(response);
    }
    //=============================================================================
    // 5. رابط تعطيل حساب موظف (PUT) - لتغيير حالته إلى false
    //=============================================================================
    @PutMapping("/{id}/deactivate")
    public ResponseEntity<String> deactivateEmployee(@PathVariable Long id) {
        employeeService.deactivateEmployee(id);
        return ResponseEntity.ok("تم إيقاف وتعطيل حساب الموظف بنجاح");
    }
    //=============================================================================
    // 6. رابط إعادة تفعيل حساب موظف (PUT) - لإرجاعه إلى true
    //=============================================================================
    @PutMapping("/{id}/activate")
    public ResponseEntity<String> activateEmployee(@PathVariable Long id) {
        employeeService.activateEmployee(id);
        return ResponseEntity.ok("تم إعادة تفعيل حساب الموظف بنجاح");
    }
    //=============================================================================
    //7. تعديل دور موظف معين في النظام البنكي عن طريق id
    //=============================================================================
    @PutMapping("/{id}/role")
    public ResponseEntity<EmployeeResponseDTO> updateEmployeeRole(@PathVariable Long id, @RequestParam String newRole) {
        // استدعاء دالة الـ Service التي جهزناها في الخطوة الأولى
        EmployeeResponseDTO updatedEmployee = employeeService.updateEmployeeRole(id, newRole);
        // إرجاع البيانات المحدثة مع حالة 200 OK للمتصفح
        return ResponseEntity.ok(updatedEmployee);
    }
    //============================================================================
    //8.حذف بيانات موظف
    //=============================================================================
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable Long id) {
        // استدعاء دالة الحذف من الـ Service
        employeeService.deleteEmployee(id);
        // في الـ REST API، يفضل إرجاع حالة noContent (Status 204) عند نجاح الحذف لأنه لا توجد بيانات لإعادتها
        return ResponseEntity.noContent().build();
    }
    //=============================================================================
    //9.تعديل كامل لبيانات احد الموظفين
    //=============================================================================
    @PutMapping("/{id}")
    public ResponseEntity<EmployeeResponseDTO> updateEmployeeFully(@PathVariable Long id, @Valid @RequestBody EmployeeUpdateRequestDTO updateRequest) { // 💡 أضفنا @Valid لتفعيل تحققات الـ DTO تلقائياً
        EmployeeResponseDTO updatedEmployee = employeeService.updateEmployeeFully(id, updateRequest);
        return ResponseEntity.ok(updatedEmployee);
    }


}
