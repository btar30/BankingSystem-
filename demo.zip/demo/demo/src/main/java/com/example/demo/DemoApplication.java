package com.example.demo;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;

// إضافة الاستثناء هنا لتعطيل الحماية التلقائية التي تولد الباسورد العشوائي
@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })


public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }
}
