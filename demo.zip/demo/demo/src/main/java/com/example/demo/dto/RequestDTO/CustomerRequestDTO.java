package com.example.demo.dto.RequestDTO;

import jakarta.validation.constraints.*;
import java.time.LocalDate;

public record CustomerRequestDTO(

        @NotBlank(message = "الاسم الأول إلزامي ولا يمكن تركه فارغاً")
        @Size(min = 2, max = 50, message = "الاسم الأول يجب أن يكون بين 2 إلى 50 حرف")
        String firstName,

        @NotBlank(message = "اسم العائلة إلزامي ولا يمكن تركه فارغاً")
        @Size(min = 2, max = 50, message = "اسم العائلة يجب أن يكون بين 2 إلى 50 حرف")
        String lastName,

        @NotNull(message = "تاريخ الميلاد إلزامي")
        @Past(message = "تاريخ الميلاد يجب أن يكون تاريخاً في الماضي")
        LocalDate dateOfBirth,

        @NotBlank(message = "رقم الهوية / جواز السفر إلزامي")
        @Size(max = 30, message = "رقم الهوية لا يجب أن يتعدى 30 خانة")
        String identityNumber,

        @NotBlank(message = "رقم الهاتف إلزامي")
        @Pattern(regexp = "^\\+?[1-9]\\d{1,14}$", message = "يرجى إدخال رقم هاتف صحيح بالصيغة الدولية (مثال: +967777777777)")
        String phoneNumber,

        @NotBlank(message = "البريد الإلكتروني إلزامي")
        @Email(message = "صيغة البريد الإلكتروني غير صحيحة")
        @Size(max = 100, message = "البريد الإلكتروني لا يجب أن يتعدى 100 حرف")
        String email,

        @NotBlank(message = "كلمة المرور إلزامية")
        @Size(min = 8, max = 32, message = "كلمة المرور يجب أن تكون بين 8 إلى 32 خانة")
        @Pattern(
                regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!]).*$",
                message = "كلمة المرور ضعيفة! يجب أن تحتوي على رقم، حرف كبير، حرف صغير، ورمز خاص واحد على الأقل"
        )
        String password,

        @NotBlank(message = "العنوان السكني إلزامي")
        @Size(max = 255, message = "العنوان لا يجب أن يتعدى 255 حرف")
        String address
) {}
