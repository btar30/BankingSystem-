package com.example.demo.controller;

import com.example.demo.dto.RequestDTO.AccountRequestDTO;
import com.example.demo.dto.ResponseDTO.AccountResponseDTO;
import com.example.demo.service.AccountService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/accounts") // المسار الرئيسي الملوكي للحسابات البنكية 🏦
@RequiredArgsConstructor
@CrossOrigin(origins = "*") // لفتح المجال (للفروم اند) للاتصال بالسيرفر بدون مشاكل الـ CORS 🌐
public class AccountController {

    private final AccountService accountService;

    // ==========================================
    // 1. إنشاء حساب بنكي جديد لعميل 💳
    // ==========================================
    @PostMapping
    public ResponseEntity<AccountResponseDTO> createAccount(@Valid @RequestBody AccountRequestDTO requestDTO) {
        AccountResponseDTO response = accountService.createAccount(requestDTO);

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    // ==========================================
    // 2. جلب بيانات حساب معين عن طريق رقم الحساب 🔍
    // ==========================================
    @GetMapping("/{accountNumber}")
    public ResponseEntity<AccountResponseDTO> getAccountByNumber(@PathVariable String accountNumber) {
        AccountResponseDTO response = accountService.getAccountByNumber(accountNumber);
        return ResponseEntity.ok(response); // تعيد HttpStatus.OK (200)
    }

    // ==========================================
    // 3. جلب جميع الحسابات التابعة لعميل محدد عبر الـ CIF 📊
    // ==========================================
    @GetMapping("/customer/{customerCif}")
    public ResponseEntity<List<AccountResponseDTO>> getAccountsByCustomerCif(@PathVariable String customerCif) {
        List<AccountResponseDTO> response = accountService.getAccountsByCustomerCif(customerCif);
        return ResponseEntity.ok(response);
    }

    // ==========================================
    // 4. عملية الإيداع المالي في حساب 💰➕
    // ==========================================
    @PostMapping("/{accountNumber}/deposit")
    public ResponseEntity<AccountResponseDTO> deposit(
            @PathVariable String accountNumber,
            @RequestParam BigDecimal amount) {

        AccountResponseDTO response = accountService.deposit(accountNumber, amount);
        return ResponseEntity.ok(response);
    }

    // ==========================================
    // 5. عملية السحب المالي من حساب 💰➖
    // ==========================================
    @PostMapping("/{accountNumber}/withdraw")
    public ResponseEntity<AccountResponseDTO> withdraw(
            @PathVariable String accountNumber,
            @RequestParam BigDecimal amount) {

        AccountResponseDTO response = accountService.withdraw(accountNumber, amount);
        return ResponseEntity.ok(response);
    }

    // ==========================================
    // 6. عملية التحويل المالي بين حسابين 💸✈️
    // ==========================================
    @PostMapping("/transfer")
    public ResponseEntity<Map<String, String>> transfer(
            @RequestParam String sourceAccountNumber,
            @RequestParam String destinationAccountNumber,
            @RequestParam BigDecimal amount) {

        accountService.transfer(sourceAccountNumber, destinationAccountNumber, amount);

        // بما أن الدالة void، نرجع رسالة نجاح منسقة داخل Map لتظهر لشهاب كـ JSON 📝
        return ResponseEntity.ok(Map.of("message", "تمت عملية التحويل المالي بنجاح! 💸"));
    }

    // ==========================================
    // 7. تجميد حساب بنكي ❄️🔒
    // ==========================================
    @PatchMapping("/{accountNumber}/freeze") // استخدمنا Patch لأننا نعدل حقل واحد فقط وهو الحالة
    public ResponseEntity<Map<String, String>> freezeAccount(@PathVariable String accountNumber) {
        accountService.freezeAccount(accountNumber);
        return ResponseEntity.ok(Map.of("message", "تم تجميد الحساب البنكي بنجاح بنجاح ❄️"));
    }

    // ==========================================
    // 8. تنشيط حساب بنكي مجمد 🔥🔓
    // ==========================================
    @PatchMapping("/{accountNumber}/activate")
    public ResponseEntity<Map<String, String>> activateAccount(@PathVariable String accountNumber) {
        accountService.activateAccount(accountNumber);
        return ResponseEntity.ok(Map.of("message", "تم إعادة تنشيط الحساب البنكي بنجاح وهو جاهز للعمليات 🔥"));
    }

    // ==========================================
    // 9. جلب جميع حسابات البنك كاملة (للإدارة والتقارير) 📈
    // ==========================================
    @GetMapping
    public ResponseEntity<List<AccountResponseDTO>> getAllAccounts() {
        List<AccountResponseDTO> response = accountService.getAllAccounts();
        return ResponseEntity.ok(response);
    }
}
