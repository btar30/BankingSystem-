package com.example.demo.exception.ExcAccount;

public class InsufficientBalanceException extends RuntimeException {    //2. خطأ "رصيد غير كافي
    public InsufficientBalanceException(String message) {
        super(message);
    }
}
