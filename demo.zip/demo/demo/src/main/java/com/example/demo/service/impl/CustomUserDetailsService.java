package com.example.demo.service.impl;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final EmployeeRepository employeeRepository;

    public CustomUserDetailsService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // البحث عن الموظف في قاعدة البيانات بواسطة اسم المستخدم ونشاطه
        Employee employee = employeeRepository.findByUsernameAndIsActiveTrue(username)
                .orElseThrow(() -> new UsernameNotFoundException("عذراً، لم يتم العثور على مستخدم نشط بهذا الاسم: " + username));

        // تحويل الموظف الخاص بنا إلى كائن يفهمه نظام أمان Spring Security
        return User.withUsername(employee.getUsername())
                .password(employee.getPassword()) // كلمة المرور المشفرة الجاهزة في قاعدة البيانات
                .roles(employee.getRole().name()) // الصلاحية (ADMIN, MANAGER, TELLER)
                .build();
    }
}
