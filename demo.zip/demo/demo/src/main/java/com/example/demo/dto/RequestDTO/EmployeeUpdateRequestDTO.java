package com.example.demo.dto.RequestDTO; // 👈 نفس الـ Package الخاصة بمشروعك الحالي

import com.example.demo.model.enums.Role;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
//=================================================================================================================
                                 //DTO مخصص لطلب تعديل بيانات الموظف كاملة
                                 // تابع لداله (updateEmployeeFully)  الذي رقمها رقم  9
//=================================================================================================================
/**
 * DTO مخصص لطلب تعديل بيانات الموظف كاملة
 * تم استبعاد حقول الحماية الحساسة (اسم المستخدم وكلمة المرور) التي لا يتم تعديلها من شاشة البيانات العامة
 */
public class EmployeeUpdateRequestDTO {

    @NotBlank(message = "الاسم الأول مطلوب")
    @Size(max = 50, message = "الاسم الأول يجب ألا يتجاوز 50 حرفاً")
    private String firstName;

    @NotBlank(message = "اسم العائلة مطلوب")
    @Size(max = 50, message = "اسم العائلة يجب ألا يتجاوز 50 حرفاً")
    private String lastName;

    @NotBlank(message = "البريد الإلكتروني مطلوب")
    @Email(message = "صيغة البريد الإلكتروني غير صحيحة")
    @Size(max = 100, message = "البريد الإلكتروني يجب ألا يتجاوز 100 حرفاً")
    private String email;

    @NotBlank(message = "رقم الهاتف مطلوب")
    @Size(max = 20, message = "رقم الهاتف يجب ألا يتجاوز 20 حرفاً")
    private String phoneNumber;

    @NotNull(message = "الراتب مطلوب")
    @Positive(message = "يجب أن يكون الراتب قيمة موجبة")
    private BigDecimal salary;

    @NotNull(message = "دور الموظف وصلاحيته مطلوبة")
    private Role role; // 👈 هنا استخدمنا الـ Role كـ Enum مباشرة تماشياً مع كودك المعتمد

    // ==========================================
    // Constructors, Getters, and Setters
    // ==========================================

    public EmployeeUpdateRequestDTO() {}

    public EmployeeUpdateRequestDTO(String firstName, String lastName, String email,
                                    String phoneNumber, BigDecimal salary, Role role) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.salary = salary;
        this.role = role;
    }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public BigDecimal getSalary() { return salary; }
    public void setSalary(BigDecimal salary) { this.salary = salary; }

    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }
}
