package com.example.demo.service;

import com.example.demo.dto.RequestDTO.CustomerRequestDTO;
import com.example.demo.dto.ResponseDTO.CustomerResponseDTO;
import java.util.List;

public interface CustomerService {

    // مهمة تسجيل عميل جديد وتوليد رقم بنكي للعميل فريد
    CustomerResponseDTO createCustomer (CustomerRequestDTO requestDTO);

     // مهمه جلب بيانات عميل محدد بواسطة رقم العميل الموحد (CIF)
    CustomerResponseDTO getCustomerByNumber(String customerNumber);

    // مهمة جلب قائمة جميع العملاء في النظام
    List<CustomerResponseDTO> getAllCustomers();

    // مهمه تحديث بيانات التواصل للعميل (الهاتف، البريد الإلكتروني، العنوان)
    CustomerResponseDTO updateCustomer(String customerNumber, CustomerRequestDTO requestDTO);

    //تجميد حساب عميل بدل حذفه
    void deactivateCustomer(String customerNumber);

    // إعادة تفعيل حساب العميل بعد التحقق ومراجعة الإدارة.
    void activateCustomer(String customerityNumber);

}
