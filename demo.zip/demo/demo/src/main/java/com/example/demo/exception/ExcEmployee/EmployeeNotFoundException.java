package com.example.demo.exception.ExcEmployee;
//خاص بخطاء خطاءالموظف غير موجود
public class EmployeeNotFoundException extends RuntimeException {//Employee داله التقاط الغلط الخاصه بجدول الموظفين
    public EmployeeNotFoundException(String message) {
        super(message);
    }
}
