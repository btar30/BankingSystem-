package com.example.demo.dto.ResponseDTO;


import com.example.demo.model.enums.AccountStatus;
import com.example.demo.model.enums.AccountType;
import com.example.demo.model.enums.CurrencyType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record AccountResponseDTO(
        Long id,
        String accountNumber,
        String iban,
        AccountType accountType,
        CurrencyType currency,
        BigDecimal balance,
        AccountStatus status,
        String customerFullName, // دمج الاسم الأول والأخير للعميل للعرض المباشر
        String customerCif,
        LocalDateTime createdAt,
        LocalDateTime updatedAt
) {}
