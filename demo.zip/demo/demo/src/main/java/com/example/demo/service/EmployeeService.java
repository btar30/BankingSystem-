package com.example.demo.service;

import com.example.demo.dto.RequestDTO.EmployeeRequestDTO;
import com.example.demo.dto.RequestDTO.EmployeeUpdateRequestDTO;
import com.example.demo.dto.ResponseDTO.EmployeeResponseDTO;
import com.example.demo.model.enums.Role;

import java.util.List;

public interface EmployeeService {

    // 1.إنشاء موظف جديد
    EmployeeResponseDTO createEmployee(EmployeeRequestDTO requestDTO);

    // 2.البحث عن موظف بالـ ID
    EmployeeResponseDTO getEmployeeById(Long id);

    // 3.جلب كل الموظفين في البنك
    List<EmployeeResponseDTO> getAllEmployees();

    // 4.جلب الموظفين بحسب دورهم (مثلاً لرؤية كل الـ Tellers)
    List<EmployeeResponseDTO> getEmployeesByRole(Role role);

    // 5.تعطيل حساب موظف (إيقافه عن العمل دون حذفه)
    void deactivateEmployee(Long id);

    // 6.تفعيل حساب موظف مجدداً
    void activateEmployee(Long id);

    //7.دالة تعديل دور موظف معين في النظام البنكي عن طريق id
    EmployeeResponseDTO updateEmployeeRole(Long id, String newRole);

    // 8.حذف بيانات موظف
    void deleteEmployee(Long id);

    //9.تعديل كامل لبيانات احد الموظفين
    EmployeeResponseDTO updateEmployeeFully(Long id, EmployeeUpdateRequestDTO updateRequest);



}


