package com.example.demo.dto.RequestDTO;

import com.example.demo.model.enums.AccountType;
import com.example.demo.model.enums.CurrencyType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;

public record AccountRequestDTO(

        @NotNull(message = "عذراً، يجب تحديد رقم العميل الموحد CIF لربط الحساب به")
        @Size(min = 12, max = 15, message = "رقم العميل الموحد CIF غير صحيح")
        String customerCif,

        @NotNull(message = "يرجى تحديد نوع الحساب (CURRENT, SAVINGS, INVESTMENT)")
        AccountType accountType,

        @NotNull(message = "يرجى تحديد عملة الحساب (YER, USD, SAR, AED)")
        CurrencyType currency,

        @NotNull(message = "الرصيد الافتتاحي مطلوب")
        @PositiveOrZero(message = "عذراً، لا يمكن أن يكون الرصيد الافتتاحي بالسالب")
        BigDecimal initialBalance
) {}
