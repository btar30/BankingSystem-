package com.example.demo.model.enums;

public enum Role {
    ADMIN,
    MANAGER,
    TELLER
}
