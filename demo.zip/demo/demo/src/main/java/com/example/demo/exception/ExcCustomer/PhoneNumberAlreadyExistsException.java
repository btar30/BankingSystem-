package com.example.demo.exception.ExcCustomer;

public class PhoneNumberAlreadyExistsException extends RuntimeException {//الكلاس الجديد لأخطاء العملاء
    public PhoneNumberAlreadyExistsException(String message) {
        super(message);
    }
}
