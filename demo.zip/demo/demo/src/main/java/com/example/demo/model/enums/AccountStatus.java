package com.example.demo.model.enums;

public enum AccountStatus {
    ACTIVE,   // نشط وشغال تماماً
    FROZEN,   // مجمد (يمنع السحب والإيداع ويصطاده حارس الـ AccountFrozenException)
    CLOSED    // مغلق نهائياً ولا يمكن إعادة استخدامه
}
