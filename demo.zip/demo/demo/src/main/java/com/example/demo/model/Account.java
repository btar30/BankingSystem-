package com.example.demo.model;

import com.example.demo.model.enums.AccountStatus;
import com.example.demo.model.enums.AccountType;
import com.example.demo.model.enums.CurrencyType;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;



// ==========================================
// 2. كلاس الحساب البنكي المطور (Account Entity)
// ==========================================
@Entity
@Table(name = "accounts")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // رقم الحساب البنكي الداخلي (فريد وإلزامي)
    @Column(name = "account_number", nullable = false, unique = true, length = 20)
    private String accountNumber;

    // رقم الحساب الدولي (IBAN) - متطلب أساسي في الأنظمة البنكية الحديثة
    @Column(name = "iban", nullable = false, unique = true, length = 34)
    private String iban;

    // نوع العملة باستخدام الـ Enum لضمان عدم إدخال رموز خاطئة
    @Enumerated(EnumType.STRING)
    @Column(name = "currency", nullable = false, length = 10)
    private CurrencyType currency;

    // نوع الحساب (جاري، توفير...) باستخدام الـ Enum
    @Enumerated(EnumType.STRING)
    @Column(name = "account_type", nullable = false, length = 20)
    private AccountType accountType;

    // الرصيد الحالي للحساب (إلزامي ويبدأ بالـ initial balance عند الإنشاء)
    @Column(name = "balance", nullable = false, precision = 18, scale = 3)
    private BigDecimal balance;

    // حالة الحساب (نشط، مجمد، مغلق) بديل احترافي لحقل الـ boolean
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    @Builder.Default
    private AccountStatus status = AccountStatus.ACTIVE;

    // تاريخ ووقت إنشاء الحساب بالثانية والدقيقة
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    // تاريخ ووقت آخر حركة أو تعديل تم على الحساب
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // ربط الحساب بالعميل الملوكي (علاقة Many-To-One) مع ضبط الـ Lazy لأداء خارق
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", referencedColumnName = "id", nullable = false)
    @ToString.Exclude // منعا للـ Infinite Loop مع كلاس العميل
    private Customer customer;

    // تسجيل التاريخ تلقائياً عند الحفظ لأول مرة بالساعة والدقيقة
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        if (this.balance == null) {
            this.balance = BigDecimal.ZERO; // ضمان عدم بقاء الرصيد null
        }
    }

    // تحديث تاريخ التعديل تلقائياً عند حدوث أي عملية سحب أو إيداع أو تغيير حالة
    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
