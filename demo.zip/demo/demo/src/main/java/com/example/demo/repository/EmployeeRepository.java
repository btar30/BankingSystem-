content://com.android.externalstorage.documents/tree/primary%3ADownload%2Fdemo%2Fdemo::primary:Download/demo/demo/src/main/java/com/example/demo/repository/EmployeeRepository.javapackage com.example.demo.repository;

import com.example.demo.model.Employee;
import com.example.demo.model.enums.Role; // استيراد الـ Enum الصحيح
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal; // استيراد الـ BigDecimal للرواتب
import java.util.Optional;
import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // ==========================================
    // 1. دوال الأمان وتسجيل الدخول (Security & Auth)
    // ==========================================
    Optional<Employee> findByUsername(String username);

    Optional<Employee> findByUsernameAndIsActiveTrue(String username);

    boolean existsByRole(Role role);

    // إضافة: دوال أساسية لمنع تكرار البيانات أثناء إنشاء موظف جديد
    boolean existsByUsername(String username);

    boolean existsByEmail(String email);

    // ==========================================
    // 2. دوال البحث الإداري والتقارير (Management & Reports)
    // ==========================================
    List<Employee> findBySalaryGreaterThan(BigDecimal salary);

    List<Employee> findByRole(Role role);

    List<Employee> findByIsActive(boolean isActive);

    List<Employee> findBySalaryBetween(BigDecimal minSalary, BigDecimal maxSalary);

    // ==========================================
    // 3. دوال البحث الذكي والفلترة (Smart Search)
    // ==========================================

    List<Employee> findByUsernameContainingIgnoreCase(String username);
}
