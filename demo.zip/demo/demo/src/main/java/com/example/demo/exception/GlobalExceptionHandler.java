package com.example.demo.exception;

import com.example.demo.exception.ExcAccount.AccountFrozenException;
import com.example.demo.exception.ExcAccount.AccountNotFoundException;
import com.example.demo.exception.ExcAccount.InsufficientBalanceException;
import com.example.demo.exception.ExcCustomer.CustomerNotFoundException;
import com.example.demo.exception.ExcCustomer.IdentityNumberAlreadyExistsException;
import com.example.demo.exception.ExcCustomer.PhoneNumberAlreadyExistsException;
import com.example.demo.exception.ExcCustomer.EmailAlreadyExistsException; // استيراد الاكسبشن الجديد للعملاء
import com.example.demo.exception.ExcEmployee.BadRequestException;
import com.example.demo.exception.ExcEmployee.EmployeeNotFoundException;
import com.example.demo.exception.ExcEmployee.UsernameAlreadyExistsException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

@ControllerAdvice
public class GlobalExceptionHandler { // الكلاس يراقب النظام بالكامل ويصطاد الأخطاء

    //================================================================================
    //                        اكسبشن الخاص بكلاس الموظفين
    //================================================================================

    // 1. الحارس الأول: صيد خطأ " اسم المستخدم مكرر "(موجود مسبقاً)
    @ExceptionHandler(UsernameAlreadyExistsException.class)
    public ResponseEntity<ErrorResponse> handleUsernameResponse(UsernameAlreadyExistsException ex) {
        ErrorResponse errorDetails = new ErrorResponse(
                LocalDateTime.now(),             // التاريخ
                HttpStatus.BAD_REQUEST.value(), // رقم 400
                "Bad Request",
                ex.getMessage()               // الرسالة القادمة من دالة السيرفيس
        );
        return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
    }

    // 2.الحارس الثاني: في حالة البحث "خطاءالموظف غير موجود" ً
    @ExceptionHandler(EmployeeNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleEmployeeNotFound(EmployeeNotFoundException ex) {
        ErrorResponse errorDetails = new ErrorResponse(
                LocalDateTime.now(),
                HttpStatus.NOT_FOUND.value(), // رقم 404 المخصص للمواد غير الموجودة
                "Not Found",
                ex.getMessage() // الرسالة القادمة من دالة السيرفيس
        );
        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
    }

    // 3.الحارس الثالث: الصلاحية المدخلة غير مدعومة في النظام البنكي." ً
    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<ErrorResponse> handleEmployeeNotFound(BadRequestException ex) {
        ErrorResponse errorDetails = new ErrorResponse(
                LocalDateTime.now(),
                HttpStatus.NOT_FOUND.value(),
                "Not Found",
                ex.getMessage()
        );
        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
    }

    //=========================================================================
    // اكسبشن الاخطاء الخاص بكلاس العملاء
    //=========================================================================

    // 3.الحارس الثالث: صيد خطأ رقم الهوية المكرر
    @ExceptionHandler(IdentityNumberAlreadyExistsException.class)
    public ResponseEntity<ErrorResponse> handleIdentityNumberAlreadyExists(IdentityNumberAlreadyExistsException ex) {
        ErrorResponse error = new ErrorResponse(
                LocalDateTime.now(),
                HttpStatus.BAD_REQUEST.value(),
                "IDENTITY_ALREADY_EXISTS",
                ex.getMessage()
        );
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    // 4.الحارس الرابع : صيد خطأ العميل غير الموجود
    @ExceptionHandler(CustomerNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleCustomerNotFound(CustomerNotFoundException ex) {
        ErrorResponse error = new ErrorResponse(
                LocalDateTime.now(),
                HttpStatus.NOT_FOUND.value(),
                "CUSTOMER_NOT_FOUND",
                ex.getMessage()
        );
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    // 5.الحارس الخامس: صيد خطأ رقم الهاتف المكرر
    @ExceptionHandler(PhoneNumberAlreadyExistsException.class)
    public ResponseEntity<ErrorResponse> handlePhoneNumberAlreadyExists(PhoneNumberAlreadyExistsException ex) {
        ErrorResponse error = new ErrorResponse(
                LocalDateTime.now(),
                HttpStatus.BAD_REQUEST.value(),
                "PHONE_ALREADY_EXISTS",
                ex.getMessage()
        );
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    // 5 . الحارس الجديد المضاف لقسم العملاء: صيد خطأ البريد الإلكتروني المكرر
    @ExceptionHandler(EmailAlreadyExistsException.class)
    public ResponseEntity<ErrorResponse> handleEmailAlreadyExists(EmailAlreadyExistsException ex) {
        ErrorResponse error = new ErrorResponse(
                LocalDateTime.now(),
                HttpStatus.BAD_REQUEST.value(),
                "EMAIL_ALREADY_EXISTS",
                ex.getMessage()
        );
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    // حارس مضاف لقسم العملاء: التقاط أخطاء الـ Validation المخصصة للـ Record (مثل الرسائل العربية عند نقص حقل أو ضعف كلمة مرور)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationExceptions(MethodArgumentNotValidException ex) {
        FieldError fieldError = ex.getBindingResult().getFieldError();
        String errorMessage = (fieldError != null) ? fieldError.getDefaultMessage() : "خطأ في التحقق من صحة البيانات القادمة";

        ErrorResponse error = new ErrorResponse(
                LocalDateTime.now(),
                HttpStatus.BAD_REQUEST.value(),
                "VALIDATION_FAILED",
                errorMessage
        );
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    //=========================================================================
    // اكسبشن الاخطاء الخاص بكلاس الحسابات البنكية
    //=========================================================================

    // 6. الحارس السادس: صيد خطأ "الحساب غير موجود"
    @ExceptionHandler(AccountNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleAccountNotFound(AccountNotFoundException ex) {
        ErrorResponse error = new ErrorResponse(
                LocalDateTime.now(),
                HttpStatus.NOT_FOUND.value(),
                "ACCOUNT_NOT_FOUND",
                ex.getMessage()
        );
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    // 7. الحارس السابع: صيد خطأ "الرصيد غير كافٍ"
    @ExceptionHandler(InsufficientBalanceException.class)
    public ResponseEntity<ErrorResponse> handleInsufficientBalance(InsufficientBalanceException ex) {
        ErrorResponse error = new ErrorResponse(
                LocalDateTime.now(),
                HttpStatus.BAD_REQUEST.value(),
                "INSUFFICIENT_BALANCE",
                ex.getMessage()
        );
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    //=========================================================================
    // اكسبشن الاخطاء الخاص بكلاس  العمليات البنكيه
    //=========================================================================

    // 8. الحارس الثامن : صيد خطأ الحساب البنكي المجمد"هذا الحساب البنكي مجمد حالياً!ٍ"
    @ExceptionHandler(AccountFrozenException.class)
    public ResponseEntity<Map<String, Object>> handleAccountFrozenException(AccountFrozenException ex) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("status", HttpStatus.BAD_REQUEST.value());
        body.put("error", "Account Frozen");
        body.put("message", ex.getMessage());

        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }

    // ابقِ فقط على هذه الدالة الموحدة واحذف أي دالة أخرى تراقب Exception.class
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGlobalException(Exception exception, WebRequest webRequest) {

        // طباعة السطور الحمراء بالتفصيل في الـ Console لمعرفة سبب مشكلة الـ createdAt
        exception.printStackTrace();

        ErrorResponse errorResponse = new ErrorResponse(
                LocalDateTime.now(),
                HttpStatus.INTERNAL_SERVER_ERROR.value(), // 500
                HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), // Internal Server Error
                "حدث خطأ داخلي في النظام، يرجى المحاولة لاحقاً أو التواصل مع الإدارة."
        );

        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
