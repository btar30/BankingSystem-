package com.example.demo.repository;

import aj.org.objectweb.asm.commons.Remapper;
import com.example.demo.model.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {


    //1.البحث عن حساب بواسطه رقمه الداخلي
    Optional<Account> findByAccountNumber(String accountNumber);
//find

    //2.البحث عن حساب بواسطه رقم IBAN الدولي
    Optional<Account> findByIban(String iban);//find

    // 3. جلب جميع الحسابات التابعة لعميل معين عبر رقم الـ CIF الخاص به
    // استخدمنا JOIN FETCH لضمان جلب البيانات بسرعة وبدون مشكلة الـ Lazy Loading
    @Query("SELECT a FROM Account a JOIN FETCH a.customer c WHERE c.customerNumber = :customerNumber")
    List<Account> findByCustomerNumber(@Param("customerNumber") String customerNumber);

    // 4. التحقق من وجود رقم حساب مسبقاً في النظام لمنع التكرار
    boolean existsByAccountNumber(String accountNumber);//exists

    // 5. التحقق من وجود رقم الـ IBAN مسبقاً في النظام
    boolean existsByIban(String iban);//exists

    // 6. استعلام بنكي متقدم: حساب إجمالي أرصدة العميل لعملة معينة (مثلاً: كم يملك أحمد إجمالي ريال يمني في البنك؟)
    @Query("SELECT SUM(a.balance) FROM Account a WHERE a.customer.customerNumber = :customerNumber AND a.currency = :currency")
    BigDecimal getSumOfBalanceByCustomerAndCurrency(@Param("customerNumber") String customerNumber, @Param("currency") String currency);


}
