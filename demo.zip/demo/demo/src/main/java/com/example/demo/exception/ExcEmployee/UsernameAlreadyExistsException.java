package com.example.demo.exception.ExcEmployee;
//خاص بخطأ "اسم المستخدم مكرر"
// ورثنا من RuntimeException لكي يلتقطه السبرنج بوت تلقائياً أثناء تشغيل النظام
public class UsernameAlreadyExistsException extends RuntimeException {

    // مشيد يستقبل رسالة الخطأ ويمررها للكلاس الأصلي
    public UsernameAlreadyExistsException(String message) {
        super(message);
    }
}
