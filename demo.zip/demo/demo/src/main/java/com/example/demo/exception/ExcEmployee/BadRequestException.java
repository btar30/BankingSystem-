package com.example.demo.exception.ExcEmployee;


public class BadRequestException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    // مشيد يستقبل رسالة الخطأ المخصصة ويصعدها للكلاس الأب RuntimeException
    public BadRequestException(String message) {
        super(message);
    }
}





