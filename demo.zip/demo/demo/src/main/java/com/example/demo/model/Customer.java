package com.example.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "customers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class Customer {
    //=================================================================================
    //                       حقول العملاء
    //=================================================================================

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "رقم العميل الموحد (CIF) إلزامي")
    @Size(min = 12, max = 12, message = "رقم العميل الموحد يجب أن يكون مكوناً من 12 خانة")
    @Column(nullable = false, unique = true, length = 12, updatable = false)
    private String customerNumber;

    @NotBlank(message = "الاسم الأول إلزامي")
    @Size(min = 2, max = 50, message = "الاسم الأول يجب أن يكون بين 2 إلى 50 حرف")
    @Column(nullable = false, length = 50)
    private String firstName;

    @NotBlank(message = "اسم العائلة إلزامي")
    @Size(min = 2, max = 50, message = "اسم العائلة يجب أن يكون بين 2 إلى 50 حرف")
    @Column(nullable = false, length = 50)
    private String lastName;

    @NotNull(message = "تاريخ الميلاد إلزامي")
    @Past(message = "تاريخ الميلاد يجب أن يكون في الماضي")
    @Column(nullable = false)
    private LocalDate dateOfBirth;

    @NotBlank(message = "رقم الهوية او جواز السفر إلزامي")
    @Size(max = 30, message = "رقم الهوية لا يجب أن يتعدى 30 خانة")
    @Column(nullable = false, unique = true, length = 30)
    private String identityNumber;

    @NotBlank(message = "رقم الهاتف إلزامي")
    @Pattern(regexp = "^\\+?[1-9]\\d{1,14}$", message = "يرجى إدخال رقم هاتف صحيح بالصيغة الدولية")
    @Column(nullable = false, unique = true, length = 20)
    private String phoneNumber;

    @Email(message = "صيغة البريد الإلكتروني غير صحيحة")
    @Size(max = 100, message = "البريد الإلكتروني لا يجب أن يتعدى 100 حرف")
    @Column(unique = true, length = 100)
    private String email;

    @NotBlank(message = "كلمة المرور إلزامية")
    @Column(nullable = false, length = 255) // طول 255 لتستوعب التشفير (BCrypt) مستقبلاً
    private String password;

    @NotBlank(message = "العنوان السكني إلزامي")
    @Column(nullable = false, length = 255)
    private String address;

    @Column(nullable = false)
    private boolean isActive = true; //هل الحساب نشط او معطل

    // التاريخ والوقت بالكامل بالساعة والدقيقة والثانية
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    // علاقة الحسابات المتعددة مع استبعادها من الـ ToString منعاً للـ Infinite Loop
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @ToString.Exclude
    @Builder.Default
    private List<Account> accounts = new ArrayList<>();

    // إدخال تاريخ ووقت إنشاء العميل تلقائياً بالساعة والدقيقة عند الحفظ لأول مرة
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }
}
