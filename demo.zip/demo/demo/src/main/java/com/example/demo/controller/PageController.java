package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller // لاحظ استخدمنا @Controller عادية لعرض الصفحات وليس @RestController
public class PageController {

    // 1. رابط فتح لوحة التحكم
    @GetMapping("/dashboard")
    public String showDashboard() {
        return "dashboard"; // سيبحث السيرفر تلقائياً عن dashboard.html داخل مجلد static
    }

    // 2. رابط فتح واجهة إضافة موظف جديد
    @GetMapping("/employees/add")
    public String showAddEmployeePage() {
        return "add-employee"; // سيبحث السيرفر عن add-employee.html داخل مجلد static
    }

    // 3. رابط فتح واجهة تعديل بيانات موظف
    @GetMapping("/employees/edit")
    public String showEditEmployeePage() {
        return "edit-employee"; // سيبحث السيرفر عن edit-employee.html داخل مجلد static
    }
}
