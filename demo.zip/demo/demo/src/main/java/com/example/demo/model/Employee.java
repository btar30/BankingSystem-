//package com.example.demo.model;
//
//import jakarta.persistence.*;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;

//@Entity
//@Table(name = "employees") // تحديد اسم الجدول في SQL
//@Data // توليد الـ Getters والـ Setters تلقائياً
//@NoArgsConstructor // مشيد فارغ (ضروري للـ JPA)
//@AllArgsConstructor // مشيد بكل الحقول
//public class Employee {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    @Column(nullable = false, unique = true) // الاسم لا يمكن أن يكون فارغاً وهو فريد
//    private String username;
//
//    @Column(nullable = false)
//    private String password; // كلمة المرور (جديد)
//
//    @Column(nullable = false)
//    private String role; // الصلاحيات (Admin, User, Employee) - (جديد)
//
//    private Double salary;
//
//    // الربط مع كلاس الحساب (One-to-One)
//    // وضعنا FetchType.LAZY لتحسين الأداء (لا يتم جلب الحساب إلا عند الحاجة)
//    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JoinColumn(name = "account_id", referencedColumnName = "id")
//    private Account account;
//
//    public Long getId() {
//        return id;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public String getUsername() {
//        return username;
//    }
//
//    public void setUsername(String username) {
//        this.username = username;
//    }
//
//    public String getPassword() {
//        return password;
//    }
//
//    public void setPassword(String password) {
//        this.password = password;
//    }
//
//    public String getRole() {
//        return role;
//    }
//
//    public void setRole(String role) {
//        this.role = role;
//    }
//
//    public Double getSalary() {
//        return salary;
//    }
//
//    public void setSalary(Double salary) {
//        this.salary = salary;
//    }
//
//    public Account getAccount() {
//        return account;
//    }
//
//    public void setAccount(Account account) {
//        this.account = account;
//    }
//}

package com.example.demo.model;

import com.example.demo.model.enums.Role;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "employees")
            //================================================================================
            //================================================================================
            //                                    كلاس الموظفين
            //================================================================================
            //================================================================================
public class Employee {

    // 1. الرقم التعريفي الفريد (Primary Key) تلقائي التوليد في SQL Server
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    // 2. الاسم الأول (ممنوع فارغ وبطول محدد)
    @NotBlank(message = "الاسم الأول مطلوب ولا يمكن أن يكون فارغاً")
    @Size(max = 50, message = "الاسم الأول يجب ألا يتجاوز 50 حرفاً")
    @Column(name = "first_name", nullable = false, length = 50)
    private String firstName;

    // 3. الاسم الأخير / العائلة
    @NotBlank(message = "اسم العائلة مطلوب")
    @Size(max = 50, message = "اسم العائلة يجب ألا يتجاوز 50 حرفاً")
    @Column(name = "last_name", nullable = false, length = 50)
    private String lastName;

    // 4. البريد الإلكتروني (فريد، مع التحقق من الصيغة البنكية الرسمية)
    @NotBlank(message = "البريد الإلكتروني مطلوب")
    @Email(message = "صيغة البريد الإلكتروني غير صحيحة")
    @Size(max = 100, message = "البريد الإلكتروني يجب ألا يتجاوز 100 حرفاً")
    @Column(name = "email", nullable = false, unique = true, length = 100)
    private String email;

    // 5. رقم الهاتف
    @NotBlank(message = "رقم الهاتف مطلوب")
    @Size(max = 20, message = "رقم الهاتف يجب ألا يتجاوز 20 حرفاً")
    @Column(name = "phone_number", nullable = false, length = 20)
    private String phoneNumber;

    // 6. الراتب الحالي للموظف (BigDecimal لضمان دقة العملات والكسور بدون تقريب عشوائي)
    @NotNull(message = "الراتب مطلوب")
    @Positive(message = "يجب أن يكون الراتب قيمة موجبة أكبر من الصفر")
    @Column(name = "salary", nullable = false, precision = 10, scale = 2)
    private BigDecimal salary;

    // 7. تاريخ التعيين في البنك
    @NotNull(message = "تاريخ التعيين مطلوب")
    @Column(name = "hire_date", nullable = false)
    private LocalDate hireDate;

    // 8. اسم المستخدم لتسجيل الدخول (فريد وحساس للحماية)
    @NotBlank(message = "اسم المستخدم مطلوب")
    @Size(min = 4, max = 50, message = "اسم المستخدم يجب أن يكون بين 4 إلى 50 حرفاً")
    @Column(name = "username", nullable = false, unique = true, length = 50)
    private String username;

    // 9. كلمة المرور (طول 255 حرفاً لاستيعاب هاش التشفير المعقد الناتج من BCrypt)
    @NotBlank(message = "كلمة المرور مطلوبة")
    @Column(name = "password", nullable = false, length = 255)
    private String password;

    // 10. دور الموظف وصلاحياته (ADMIN, MANAGER, TELLER) باستخدام Enum
    @NotNull(message = "دور الموظف وصلاحيته مطلوبة")
    @Enumerated(EnumType.STRING)
    @Column(name = "role", nullable = false, length = 20)
    private Role role;

    // 11. حالة الحساب (نشط أم موقوف)
    @Column(name = "is_active", nullable = false)
    private boolean isActive = true;

    // ==========================================================
    // حقول الرقابة والتدقيق البنكية المضافة حديثاً (Auditing Fields)
    // ==========================================================

    //تسجيل تاريخ الاضافه
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    //تسجيل تاريخ التعديل
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // تشغيل التوقيت التلقائي عند الإنشاء والتعديل الفعلي في قاعدة البيانات
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    // ==========================================
    // الـ Constructors (المشيدات)
    // ==========================================
    public Employee() { } //مشيد فارغ

    public Employee(Long id, String firstName, String lastName, String email, String phoneNumber,
                    BigDecimal salary, LocalDate hireDate, String username, String password, Role role, boolean isActive)
        {
            this.id = id;
            this.firstName = firstName;
            this.lastName = lastName;
            this.email = email;
            this.phoneNumber = phoneNumber;
            this.salary = salary;
            this.hireDate = hireDate;
            this.username = username;
            this.password = password;
            this.role = role;
            this.isActive = isActive;
        }

    // ==========================================
    // الـ Getters والـ Setters
    // ==========================================

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public BigDecimal getSalary() { return salary; }
    public void setSalary(BigDecimal salary) { this.salary = salary; }

    public LocalDate getHireDate() { return hireDate; }
    public void setHireDate(LocalDate hireDate) { this.hireDate = hireDate; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public LocalDateTime getCreatedAt() { return createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }

    // ==========================================
    // دالة toString مخصصة ومحمية أمنياً
    // ==========================================
    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", username='" + username + '\'' +
                ", role=" + role +
                ", isActive=" + isActive +
                ", createdAt=" + createdAt +
                '}'; // لاحظ هنا: قمنا بحذف الـ password تماماً لحمايتها من التسريب في ملفات الـ Logs
    }


    // أضف هذه الدالتين يدوياً في أسفل كلاس Employee.java



    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

}
