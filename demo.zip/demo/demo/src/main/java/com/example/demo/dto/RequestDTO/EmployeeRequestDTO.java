package com.example.demo.dto.RequestDTO;

import com.example.demo.model.enums.Role;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public class EmployeeRequestDTO { //خاص بتعبئه البيانات الامن

    @NotBlank(message = "الاسم الأول مطلوب")
    @Size(max = 50, message = "الاسم الأول يجب ألا يتجاوز 50 حرفاً")
    private String firstName;

    @NotBlank(message = "اسم العائلة مطلوب")
    @Size(max = 50, message = "اسم العائلة يجب ألا يتجاوز 50 حرفاً")
    private String lastName;

    @NotBlank(message = "البريد الإلكتروني مطلوب")
    @Email(message = "صيغة البريد الإلكتروني غير صحيحة")
    @Size(max = 100, message = "البريد الإلكتروني يجب ألا يتجاوز 100 حرفاً")
    private String email;

    @NotBlank(message = "رقم الهاتف مطلوب")
    @Size(max = 20, message = "رقم الهاتف يجب ألا يتجاوز 20 حرفاً")
    private String phoneNumber;

    @NotNull(message = "الراتب مطلوب")
    @Positive(message = "يجب أن يكون الراتب قيمة موجبة")
    private BigDecimal salary;

    @NotBlank(message = "اسم المستخدم مطلوب")
    @Size(min = 4, max = 50, message = "اسم المستخدم يجب أن يكون بين 4 إلى 50 حرفاً")
    private String username;

    @NotBlank(message = "كلمة المرور مطلوبة")
    @Size(min = 6, message = "يجب ألا تقل كلمة المرور عن 6 أحرف أو رموز")
    @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).+$",message = "يجب أن تحتوي كلمة المرور على حرف كبير وصغير ورقم واحد على الأقل")
    private String password;

    @NotNull(message = "دور الموظف وصلاحيته مطلوبة")
    private Role role;

    // ==========================================
    // Constructors, Getters, and Setters
    // ==========================================

    public EmployeeRequestDTO() {}

    public EmployeeRequestDTO(String firstName, String lastName, String email, String phoneNumber,
                              BigDecimal salary, String username, String password, Role role) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.salary = salary;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public BigDecimal getSalary() { return salary; }
    public void setSalary(BigDecimal salary) { this.salary = salary; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }
}

