package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

//    @Bean
//    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//        http
//                // 1. إيقاف حماية CSRF لكي يسمح للـ Postman والمتصفح بإرسال طلبات الـ POST/PUT بنجاح
//                .csrf(csrf -> csrf.disable())
//
//                .authorizeHttpRequests(auth -> auth
//                        // 🌟 التصحيح هنا: السماح للجميع بفتح كافة صفحات الـ HTML الثابتة بما فيها التعديل الشامل
//                        .requestMatchers(
//                                "/login.html",
//                                "/dashboard.html",
//                                "/add-employee.html",
//                                "/edit-employee.html", // تفعيل الامتداد ليتوافق مع طلب المتصفح
//                                "/employees/**"        // السماح بمسارات الـ PageController إذا تم استدعاؤها
//                        ).permitAll()
//
//                        // حماية روابط الـ API وجعلها مقتصرة على المدير ذو صلاحية ADMIN
//                        .requestMatchers("/api/v1/employees/**").hasRole("ADMIN")
//
//                        .anyRequest().authenticated()
//                )
//
//                // 2. تفعيل الـ Form Login للمتصفح والواجهات الحالية
//                .formLogin(form -> form
//                        .loginPage("/login.html") // صفحة الدخول المعتمدة
//                        .loginProcessingUrl("/login")
//                        .defaultSuccessUrl("/dashboard.html", true)
//                        .permitAll()
//                )
//
//                // 3. تفعيل الـ Basic Auth لكي يستقبل السيرفر التوثيق المرسل في الـ Headers من الفيتش والـ Postman
//                .httpBasic(Customizer.withDefaults());
//
//        return http.build();
//    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }


//
//    @Bean
//    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//        http
//                .csrf(csrf -> csrf.disable())
//                .authorizeHttpRequests(auth -> auth
//                        // 🌟 أضف هذه الأسطر الثلاثة هنا لفتح روابط سوجر
//                        .requestMatchers("/v3/api-docs/**").permitAll()
//                        .requestMatchers("/swagger-ui/**").permitAll()
//                        .requestMatchers("/swagger-ui.html").permitAll()
//                        .requestMatchers("/api/v1/customers/**").hasAnyRole("ADMIN", "BRANCH_MANAGER", "TELLER")
//
//
//
//
//                        .anyRequest().authenticated()
//                )
//                .httpBasic(Customizer.withDefaults());
//
//        return http.build();
//    }




    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        // 1. السماح للجميع بفتح واجهات الـ HTML لكي تظهر بالمتصفح
                        .requestMatchers(
                                "/login.html",
                                "/dashboard.html",
                                "/customers-list.html",
                                "/add-customer.html",
                                "/add-account.html"
                        ).permitAll()

                        // 2. فتح روابط توثيق السواجر (Swagger UI)
                        .requestMatchers("/v3/api-docs/**").permitAll()
                        .requestMatchers("/swagger-ui/**").permitAll()
                        .requestMatchers("/swagger-ui.html").permitAll()

                        // 3. تأمين الـ APIs الخاصة بالعملاء والحسابات (مسموح للمدير والمحاسب/التيلر)
                        .requestMatchers("/api/v1/customers/**").hasAnyRole("ADMIN", "BRANCH_MANAGER", "TELLER")
                        .requestMatchers("/api/v1/accounts/**").hasAnyRole("ADMIN", "BRANCH_MANAGER", "TELLER")

                        // 4. تأمين الـ API الخاص بالموظفين (السماح بالـ GET للمحاسب لنجاح تسجيل الدخول)
                        .requestMatchers("/api/v1/employees/**").hasAnyRole("ADMIN", "TELLER")

                        .anyRequest().authenticated()
                )
                .httpBasic(Customizer.withDefaults());

        return http.build();
    }


}

