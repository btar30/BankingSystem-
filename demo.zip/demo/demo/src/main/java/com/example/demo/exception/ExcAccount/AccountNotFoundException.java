package com.example.demo.exception.ExcAccount;

public class AccountNotFoundException extends RuntimeException {//. خطأ "الحساب غير
    public AccountNotFoundException(String message) {
        super(message);
    }
}
