package com.example.demo.dto.ResponseDTO;


import java.time.LocalDateTime;

public record CustomerResponseDTO(
        Long id,
        String customerNumber,
        String firstName,
        String lastName,
        String identityNumber,
        String phoneNumber,
        String email,
        String address,
        boolean isActive,
        LocalDateTime createdAt
) {}
