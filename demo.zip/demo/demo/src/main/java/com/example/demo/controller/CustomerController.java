package com.example.demo.controller;

import com.example.demo.dto.ResponseDTO.CustomerResponseDTO;
import com.example.demo.dto.RequestDTO.CustomerRequestDTO;
import com.example.demo.service.CustomerService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/customers")
public class CustomerController {

    private final CustomerService customerService;

    // حقن الـ Service عبر الـ Constructor لأداء أفضل واستقرار أعلى
    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    // ==========================================
    // 1. إنشاء عميل جديد (Create Customer)
    // ==========================================
    @PostMapping
    public ResponseEntity<CustomerResponseDTO> createCustomer(@Valid @RequestBody CustomerRequestDTO requestDTO) {
        CustomerResponseDTO response = customerService.createCustomer(requestDTO);
        return new ResponseEntity<>(response, HttpStatus.CREATED); // إرجاع كود 201 الاحترافي للإنشاء
    }

    // ==========================================
    // 2. جلب بيانات عميل بواسطة رقم الـ CIF
    // ==========================================
    @GetMapping("/{customerNumber}")
    public ResponseEntity<CustomerResponseDTO> getCustomerByNumber(@PathVariable String customerNumber) {
        CustomerResponseDTO response = customerService.getCustomerByNumber(customerNumber);
        return ResponseEntity.ok(response); // إرجاع كود 200 ومعه البيانات
    }

    // ==========================================
    // 3. جلب قائمة بكافة العملاء
    // ==========================================
    @GetMapping
    public ResponseEntity<List<CustomerResponseDTO>> getAllCustomers() {
        List<CustomerResponseDTO> responseList = customerService.getAllCustomers();
        return ResponseEntity.ok(responseList);
    }

    // ==========================================
    // 4. تعديل بيانات العميل
    // ==========================================
    @PutMapping("/{customerNumber}")
    public ResponseEntity<CustomerResponseDTO> updateCustomer(
            @PathVariable String customerNumber,
            @Valid @RequestBody CustomerRequestDTO requestDTO) {
        CustomerResponseDTO response = customerService.updateCustomer(customerNumber, requestDTO);
        return ResponseEntity.ok(response);
    }

    // ==========================================
    // 5. تعطيل حساب العميل (Soft Delete)
    // ==========================================
    @PatchMapping("/{customerNumber}/deactivate")
    public ResponseEntity<String> deactivateCustomer(@PathVariable String customerNumber) {
        customerService.deactivateCustomer(customerNumber);
        return ResponseEntity.ok("تم تجميد وتعطيل حساب العميل بنجاح.");
    }

    // ==========================================
    // 6. إعادة تفعيل حساب العميل
    // ==========================================
    @PatchMapping("/{customerNumber}/activate")
    public ResponseEntity<String> activateCustomer(@PathVariable String customerNumber) {
        customerService.activateCustomer(customerNumber);
        return ResponseEntity.ok("تم إعادة تفعيل حساب العميل بنجاح.");
    }
}
